#include "Texture.h"
#include <Windows.h>                // MultiByteToWideChar
#include <WICTextureLoader.h>       // �� DirectXTK
#include "Gfx.h"                    // Gfx::Dev()

using Microsoft::WRL::ComPtr;

Texture::Texture() {}
Texture::~Texture() { Release(); }

// UTF-8 �� UTF-16�iC++17/Win��p�E�Ȍ��j
std::wstring Texture::ToWString(const std::string& s)
{
    if (s.empty()) return {};
    const int len = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), len);
    return w;
}

HRESULT Texture::Load(std::string fileName)
{
    Release();

    auto* device = Gfx::Dev();
    if (!device) return E_POINTER;

    const std::wstring wpath = ToWString(fileName);

    // DXTK 1�s�ǂݍ��݁iWIC�Ή��t�H�[�}�b�g�j�{ SRV �쐬
    ComPtr<ID3D11Resource> tex;
    ComPtr<ID3D11ShaderResourceView> srv;

    // ����: WIC_LOADER_DEFAULT�i�K�v�Ȃ� FORCE_SRGB ���ɕύX�j
    HRESULT hr = DirectX::CreateWICTextureFromFileEx(
        device,
        wpath.c_str(),
        0,                              // maxsize = ����
        D3D11_USAGE_DEFAULT,
        D3D11_BIND_SHADER_RESOURCE,
        0,                              // CPU�A�N�Z�X�Ȃ�
        0,                              // misc flags �Ȃ�
        DirectX::WIC_LOADER_DEFAULT,    // ���[�_�[�t���O
        reinterpret_cast<ID3D11Resource**>(tex.ReleaseAndGetAddressOf()),
        srv.ReleaseAndGetAddressOf()
    );
    if (FAILED(hr)) return hr;

    // ���E�������擾�i2D�e�N�X�`���O��j
    m_width = m_height = 0;
    if (tex)
    {
        ComPtr<ID3D11Texture2D> t2d;
        if (SUCCEEDED(tex.As(&t2d)))
        {
            D3D11_TEXTURE2D_DESC d{};
            t2d->GetDesc(&d);
            m_width = d.Width;
            m_height = d.Height;
        }
    }

    m_tex = tex;
    m_srv = srv;
    return S_OK;
}

void Texture::Release()
{
    m_srv.Reset();
    m_tex.Reset();
    m_width = 0;
    m_height = 0;
}
