#pragma once
#include <vector>
#include <string>
#include <algorithm>
#include "Transform.h"
#include "Component.h"

//-----------------------------------------------------------
// GameObject�iComponent�Ή��E�ŏ��\���j
//
// - Transform ��1����
// - �e�q�֌W������
// - Component ��ێ����AUpdate/Draw ��`�d
//-----------------------------------------------------------
class GameObject
{
public:
    GameObject(GameObject* parent, const std::string& name);
    virtual ~GameObject();

    // ���C�t�T�C�N��
    virtual void Initialize() {}
    virtual void Update() {}
    virtual void Draw() {}
    virtual void Release() {}

    // Component �Ǘ�
    void AddComponent(Component* component);

    // �e�q�Ǘ�
    void AddChild(GameObject* child);

    // �c���[�X�V
    void UpdateSub();
    void DrawSub();
    void ReleaseSub();

    // �A�N�Z�T
    Transform& GetTransform() { return transform_; }
    const Transform& GetTransform() const { return transform_; }

protected:
    std::string name_;

    GameObject* parent_;
    std::vector<GameObject*> children_;
    std::vector<Component*> components_;

    Transform transform_;
};
